# Análise Espacial de Dados

## 1. Educação
- Taxa bruta de escolarização no ensino secundário (%) por Localização geográfica (NUTS - 2002) e Sexo; Anual  
- Taxa de escolarização no ensino superior (%) por Localização geográfica (NUTS - 2002); Anual  
- Proporção da população residente com pelo menos o ensino secundário completo (%) por Local de residência à data dos Censos [2021] (NUTS - 2013) e Sexo; Decenal  
- Estabelecimentos de ensino não superior (N.º) por Localização geográfica (NUTS - 2024), Tipo de estabelecimento e Natureza institucional; Anual  
- Alunas/os matriculadas/os no ensino básico em ofertas de educação e formação orientadas para jovens (N.º) por Localização geográfica (NUTS - 2013), Nível de ensino e Oferta; Anual  
- Taxa de analfabetismo (%) por Local de residência à data dos Censos [2021] (NUTS - 2024) e Sexo; Decenal  
- Taxa de retenção e desistência no ensino básico (%) por Localização geográfica (NUTS - 2002) e Nível de ensino; Anual  

## 2. Condições de Vida e Cidadania
- Proporção de votos do partido/coligação mais votado nas eleições para as Câmaras Municipais (%) por Local de residência (NUTS - 2024); Não periódica  
- Taxa de esforço do crédito para habitação permanente (%) por Localização geográfica (NUTS - 2024) e Quartis; Anual  
- População inscrita nas eleições para as Assembleias Municipais (N.º) por Local de residência (NUTS - 2024); Não periódica  
- Proporção de votos nulos nas eleições para as Assembleias Municipais (%) por Local de residência (NUTS - 2024); Não periódica  
- Taxa de abstenção nas eleições para as Câmaras Municipais (%) por Local de residência (NUTS - 2024); Não periódica  
- Taxa de abstenção nas eleições para a Presidência da República (%) por Local de residência (NUTS - 2024); Não periódica  
- Rendimento bruto declarado por habitante (€) por Localização geográfica (NUTS - 2024); Anual  
- Poder de compra per capita por Localização geográfica (NUTS - 2013); Bienal  

## 3. Construção e Habitação
- Avaliações bancárias de alojamentos familiares nos últimos 3 meses por Localização geográfica (NUTS - 2024) e Tipo de construção; Mensal  
- Reconstruções licenciadas por 100 construções novas licenciadas (N.º) por Localização geográfica (NUTS - 2002); Anual  
- Valor mediano das vendas por m² de alojamentos familiares nos últimos 12 meses (Metodologia 2022 - €) por Localização geográfica (NUTS - 2024) e Setor institucional do comprador; Trimestral  
- Novos contratos de arrendamento de alojamentos familiares (N.º) por Localização geográfica (NUTS - 2024); Anual  
- Edifícios de habitação familiar clássica (Parque habitacional - N.º) por Localização geográfica (NUTS - 2024); Anual  
- Edifícios concluídos (N.º) por Localização geográfica (NUTS - 2013) e Tipo de obra; Anual  
- Valor mediano das rendas por m² de novos contratos de arrendamento de alojamentos familiares nos últimos 12 meses (€) por Localização geográfica (NUTS - 2013); Semestral  
- População residente (N.º) nos alojamentos familiares clássicos por Local de residência à data dos Censos [2021] (NUTS - 2013), Época de construção (antes 1919; 2011-2021) e Tipo de entidade proprietária; Decenal  
- Alojamentos (N.º) por Localização geográfica à data dos Censos [2021] (NUTS - 2013) e Tipo (alojamento); Decenal  
- Densidade de alojamentos (N.º/km²) por Localização geográfica à data dos Censos [2021] (NUTS - 2013); Decenal  
- Contratos de compra e venda (N.º) de prédios por Localização geográfica (NUTS - 2013) e Tipo de prédio; Anual  

## 4. Cultura, Desporto e Lazer
- Despesas das câmaras municipais em cultura e desporto no total de despesas (%) por Localização geográfica (NUTS - 2013); Anual  
- Despesas em bibliotecas e arquivos (€) dos municípios por Localização geográfica (NUTS - 2013), Tipo de despesa e Domínio cultural (bibliotecas e arquivos); Anual  
- Sessões de espetáculos ao vivo (N.º) por Localização geográfica (NUTS - 2024); Anual  
- Espectadores de espetáculos ao vivo por habitante (N.º) por Localização geográfica (NUTS - 2024); Anual  
- Valor médio dos bilhetes vendidos de espetáculos ao vivo (€) por Localização geográfica (NUTS - 2013); Anual  
- Bens imóveis culturais (N.º) por Localização geográfica (NUTS - 2013) e Categoria de proteção (bem imóvel cultural); Anual  
- Despesas em atividades e equipamentos desportivos dos municípios por habitante (€) por Localização geográfica (NUTS - 2024); Anual  

## 5. Empresas
- Volume de negócios (€) dos estabelecimentos por Localização geográfica (NUTS - 2024) e Atividade económica (CAE Rev. 3); Anual  
- Constituição de pessoas coletivas e entidades equiparadas (N.º) por Localização geográfica (NUTS - 2024) e Atividade económica (Divisão - CAE Rev. 4); Mensal  
- Dissolução de pessoas coletivas e entidades equiparadas (N.º) por Localização geográfica (NUTS - 2024) e Atividade económica (CAE Rev. 3); Mensal  
- Pessoal ao serviço (N.º) dos estabelecimentos por Localização geográfica (NUTS - 2024) e Atividade económica (CAE Rev. 3); Anual  
- Estabelecimentos (N.º) por Localização geográfica (NUTS - 2024) e Atividade económica (CAE Rev. 3); Anual  

## 6. Crime
- Crimes registados (N.º) pelas autoridades policiais por Localização geográfica (NUTS - 2024) e Categoria de crime; Anual  
- Taxa de criminalidade (‰) por Localização geográfica (NUTS - 2024) e Categoria de crime; Anual  

## 7. Mercado de Trabalho
- Ganho mensal (€) por Localização geográfica (NUTS - 2024), Nível de educação e Quartis; Anual  
- Ganho mensal (€) por Localização geográfica (NUTS - 2024), Tipo de contrato de trabalho e Quartis; Anual  
- Ganho mensal (€) por Localização geográfica (NUTS - 2024), Grupo etário e Quartis; Anual  
- Ganho mensal (€) por Localização geográfica (NUTS - 2024), Sexo e Quartis; Anual  
- Ganho mensal (€) por Localização geográfica (NUTS - 2024), Nacionalidade e Quartis; Anual  
- Proporção da população empregada por conta de outrem com ensino superior (%) por Localização geográfica (NUTS - 2024); Anual  
- População empregada por conta de outrem (N.º) por Localização geográfica (NUTS - 2013) e Escalão de pessoal ao serviço; Anual  
- Taxa de emprego (%) por Local de residência à data dos Censos [2021] (NUTS - 2013), Sexo e Grupo etário; Decenal  
- População residente empregada ou estudante (N.º) por Local de residência à data dos Censos [2021] (NUTS - 2013), Sexo, Condição perante o trabalho e Local de trabalho ou estudo; Decenal  
- Taxa de atividade (%) da população residente por Local de residência à data dos Censos [2021] (NUTS - 2013) e Sexo; Decenal  
- População ativa (N.º) por Local de residência à data dos Censos [2021] (NUTS - 2013), Sexo, Grupo etário e Estado civil; Decenal  

## 8. População
- População estrangeira que solicitou estatuto de residente (N.º) por Local de residência (NUTS - 2013), Sexo e Nacionalidade (Grupos de países); Anual  
- Saldo natural (N.º) por Local de residência (NUTS - 2024); Anual  
- Idade da população residente (Ano) por Localização geográfica (NUTS - 2024) e Quartis; Anual  
- Saldo natural (N.º) por Local de residência (NUTS - 2013) e Tipologia de áreas urbanas; Anual  
- Densidade populacional (N.º/km²) por Local de residência (NUTS - 2013); Anual  
- Índice de renovação da população em idade ativa (N.º) por Local de residência (NUTS - 2013); Anual  
- Saldo migratório (N.º) por Local de residência (NUTS - 2024); Anual  
- População residente (N.º) por Local de residência (NUTS - 2024), Sexo e Grupo etário (Por ciclos de vida); Anual  
- Taxa de crescimento efetivo (%) por Local de residência (NUTS - 2013); Anual  

## 9. Proteção Social
- Valor médio das pensões da segurança social (€/ N.º) por Local de residência (NUTS - 2024); Anual / Tipo de pensão; Anual  
- Duração média do subsídio de desemprego da segurança social (Dia) por Local de residência (NUTS - 2024) e Sexo; Anual  
- Beneficiárias/os do abono de família para crianças e jovens da segurança social (N.º) por Local de residência (NUTS - 2024); Anual  
- Beneficiárias/os de subsídios de desemprego, da segurança social (N.º) por Local de residência (NUTS - 2013) e Sexo; Anual  
- Beneficiárias/os do rendimento social de inserção, da segurança social (N.º) por Local de residência (NUTS - 2013); Anual / por 1000 habitantes em idade ativa (‰); Anual  
- Beneficiárias/os de subsídios de desemprego, da segurança social (N.º) por Local de residência (NUTS - 2024) e Grupo etário; Anual  
- Valor processado do rendimento social de inserção da segurança social (€) por Local de residência (NUTS - 2024); Anual  
